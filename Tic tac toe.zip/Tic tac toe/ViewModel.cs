﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace Tic_tac_toe
{
    public class ViewModel : INotifyPropertyChanged
    {
        private const int N = 3;

        private string currentPlayer = "X";

        public ICommand NewGameCommand { get; }

        private Visibility isMenuVisible = Visibility.Visible;
        private Visibility isGameVisible = Visibility.Hidden;

        public Cell[,] Field { get; }

        public List<Cell> Cells { get; }

        public ICommand XOcommand { get; }

        public ICommand PlayerVsPlayerCommand { get; }

        public ICommand PlayerVsComputerCommand { get; }

        private bool isComputerMode = false;
        private bool gameOver = false;

        private readonly Random random = new Random();

        private Visibility isNewGameVisible = Visibility.Hidden;

        public Visibility IsNewGameVisible
        {
            get => isNewGameVisible;
            set
            {
                isNewGameVisible = value;
                PropertyChanged?.Invoke(
                    this,
                    new PropertyChangedEventArgs(nameof(IsNewGameVisible)));
            }
        }

        public Visibility IsMenuVisible
        {
            get => isMenuVisible;
            set
            {
                isMenuVisible = value;

                PropertyChanged?.Invoke(
                    this,
                    new PropertyChangedEventArgs(nameof(IsMenuVisible)));
            }
        }

        public Visibility IsGameVisible
        {
            get => isGameVisible;
            set
            {
                isGameVisible = value;

                PropertyChanged?.Invoke(
                    this,
                    new PropertyChangedEventArgs(nameof(IsGameVisible)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public ViewModel()
        {
            Field = new Cell[N, N];
            Cells = new List<Cell>();

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Field[i, j] = new Cell();
                    Cells.Add(Field[i, j]);
                }
            }

            XOcommand = new RelayCommand(XOMove);

            NewGameCommand = new RelayCommand(StartNewGame);

            PlayerVsPlayerCommand =
                new RelayCommand(StartPlayerVsPlayer);

            PlayerVsComputerCommand =
                new RelayCommand(StartPlayerVsComputer);
        }

        private void StartPlayerVsPlayer(object parameter)
        {
            isComputerMode = false;

            IsMenuVisible = Visibility.Hidden;
            IsGameVisible = Visibility.Visible;
        }

        private void StartPlayerVsComputer(object parameter)
        {
            isComputerMode = true;

            IsMenuVisible = Visibility.Hidden;
            IsGameVisible = Visibility.Visible;
        }

        private void XOMove(object parameter)
        {
            if (gameOver)
                return;

            Cell cell = (Cell)parameter;

            if (cell.Value != "")
                return;

            // Хід гравця
            cell.Value = currentPlayer;

            if (CheckWin())
            {
                gameOver = true;
                IsNewGameVisible = Visibility.Visible;
                MessageBox.Show($"Переміг {currentPlayer}!");
                return;
            }

            if (CheckDraw())
            {
                gameOver = true;
                IsNewGameVisible = Visibility.Visible;
                MessageBox.Show("Нічия!");
                return;
            }

            if (isComputerMode)
            {
                // Хід комп'ютера
                ComputerMove();

                if (CheckWin())
                {
                    gameOver = true;
                    IsNewGameVisible = Visibility.Visible;
                    MessageBox.Show("Переміг комп'ютер!");
                    return;
                }

                if (CheckDraw())
                {
                    gameOver = true;
                    IsNewGameVisible = Visibility.Visible;
                    MessageBox.Show("Нічия!");
                }
            }
            else
            {
                // Зміна гравця в режимі PvP
                currentPlayer = currentPlayer == "X" ? "O" : "X";
            }
        }

        private void ComputerMove()
        {
            // 1. Спроба виграти
            Cell move = FindWinningMove("O");

            // 2. Блокування суперника
            if (move == null)
                move = FindWinningMove("X");

            // 3. Випадковий вільний хід
            if (move == null)
            {
                List<Cell> emptyCells = new List<Cell>();

                for (int i = 0; i < N; i++)
                {
                    for (int j = 0; j < N; j++)
                    {
                        if (Field[i, j].Value == "")
                            emptyCells.Add(Field[i, j]);
                    }
                }

                if (emptyCells.Count == 0)
                    return;

                move = emptyCells[random.Next(emptyCells.Count)];
            }

            move.Value = "O";
        }

        private Cell FindWinningMove(string symbol)
        {
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (Field[i, j].Value != "")
                        continue;

                    // Перевіряємо, чи дасть цей хід перемогу
                    Field[i, j].Value = symbol;

                    bool canWin = CheckWin();

                    // Скасовуємо пробний хід
                    Field[i, j].Value = "";

                    if (canWin)
                        return Field[i, j];
                }
            }

            return null;
        }

        private bool CheckWin()
        {
            // Рядки
            for (int i = 0; i < N; i++)
            {
                if (Field[i, 0].Value != "" &&
                    Field[i, 0].Value == Field[i, 1].Value &&
                    Field[i, 1].Value == Field[i, 2].Value)
                {
                    return true;
                }
            }

            // Стовпці
            for (int j = 0; j < N; j++)
            {
                if (Field[0, j].Value != "" &&
                    Field[0, j].Value == Field[1, j].Value &&
                    Field[1, j].Value == Field[2, j].Value)
                {
                    return true;
                }
            }

            // Діагоналі
            if (Field[0, 0].Value != "" &&
                Field[0, 0].Value == Field[1, 1].Value &&
                Field[1, 1].Value == Field[2, 2].Value)
            {
                return true;
            }

            if (Field[0, 2].Value != "" &&
                Field[0, 2].Value == Field[1, 1].Value &&
                Field[1, 1].Value == Field[2, 0].Value)
            {
                return true;
            }

            return false;
        }

        private bool CheckDraw()
        {
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (Field[i, j].Value == "")
                        return false;
                }
            }

            return true;
        }
        private void StartNewGame(object parameter)
        {
            foreach (Cell cell in Cells)
            {
                cell.Value = "";
            }

            currentPlayer = "X";
            gameOver = false;
            isComputerMode = false;

            IsGameVisible = Visibility.Hidden;
            IsMenuVisible = Visibility.Visible;
            IsNewGameVisible = Visibility.Hidden;
        }
    }
}