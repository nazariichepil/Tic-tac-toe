﻿using System.ComponentModel;

namespace Tic_tac_toe
{
    public class Cell : INotifyPropertyChanged
    {
        private string _value = "";

        public string Value
        {
            get => _value;
            set
            {
                _value = value;
                PropertyChanged?.Invoke(
                    this,
                    new PropertyChangedEventArgs(nameof(Value)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}